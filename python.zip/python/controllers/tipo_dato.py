def entero():
    enteros=5
    return dict(enteros=enteros)
def flotantes():
    flotante=9,6
    return dict(flotante=flotante)
def booleanos():
    booleano=True
    return dict(booleano=booleano)