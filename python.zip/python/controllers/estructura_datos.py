def tuplas():
    tupla=(5,3,3,5,1,2,6,8,5)
    conteo= tupla.count(3)
    return dict(conteo=conteo, tupla=tupla)
def listas():
    lista1=["charmander, charmeleon, charizard, bulbasaur, ivysaur, venusaur"]

    lista2=["tomate, leche, queso"]
    append= lista2.append("pollo")

    lista3=["tomate, leche, queso"]
    lista3.clear()
    
    return dict(lista1=lista1, lista2=lista2, append=append, lista3=lista3)